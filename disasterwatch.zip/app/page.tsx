"use client"

import IndiaMap from "../src/components/IndiaMap"

export default function SyntheticV0PageForDeployment() {
  return <IndiaMap />
}